

const mysql = require("mysql2");

const db = mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "root",
    database : "reviews"
})


db.connect((err) => {
    if(err){
        console.log('error accurent while connecting dp : ',err);
    }else{
        console.log("MySql connected !")
    }
})

module.exports = db;