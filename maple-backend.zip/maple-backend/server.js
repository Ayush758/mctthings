// server.js
const express = require("express");
const nodemailer = require("nodemailer");
const cors = require("cors");
const mjml = require("mjml");
require("dotenv").config();

const app = express();

const allowedOrigins = [
  "https://www.maplecloudtechnologies.com",
  "http://localhost:3000",
  "https://localhost:3000",
];

app.use((req, res, next) => {
  const origin = req.headers.origin;

  if (allowedOrigins.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
  }

  res.setHeader("Access-Control-Allow-Credentials", "true");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  // Handle preflight
  if (req.method === "OPTIONS") {
    return res.sendStatus(204);
  }

  next();
});




// ---------- Middlewares ----------
app.use(express.json());

app.use((req, res, next) => {
  console.log(`Request from origin: ${req.headers.origin} | Path: ${req.path}`);
  next();
});

// ---------- Support Endpoint ----------
app.post("/support", async (req, res) => {
  const { name, email, subject, message, phone, organization } = req.body;

  if (!name || !email || !message) {
    return res.status(400).json({ error: "Name, email, and message are required" });
  }

  try {
    // Configure transporter
    const transporter = nodemailer.createTransport({
      host: process.env.SUPPORT_EMAIL_HOST,
      port: parseInt(process.env.SUPPORT_EMAIL_PORT),
      secure: true, // true for 465, false for other ports
      auth: {
        user: process.env.SUPPORT_EMAIL,
        pass: process.env.SUPPORT_PASS,
      },
    });

    // MJML email template
    const mjmlTemplate = `
      <mjml>
        <mj-body background-color="#f5f7fa">
          <mj-section>
            <mj-column background-color="#ffffff">
              <mj-text font-size="16px" color="#333333">
                You’ve received a new support message from your website. <br/><br/>
              </mj-text>
              <mj-text font-size="15px" color="#333333">
                <strong>Name:</strong> ${name}<br/>
                <strong>Email:</strong> ${email}<br/>
                <strong>Organization:</strong> ${organization || "N/A"}<br/>
                <strong>Phone:</strong> ${phone || "N/A"}<br/>
                <strong>Message:</strong> ${message}<br/>
              </mj-text>
            </mj-column>
          </mj-section>
        </mj-body>
      </mjml>
    `;

    const { html } = mjml(mjmlTemplate);

    const mailOptions = {
      from: `"Support" <${process.env.SUPPORT_EMAIL}>`,
      replyTo: email,
      to: process.env.SUPPORT_RECEIVER,
      subject: subject || "Support Request",
      html: html,
    };

    await transporter.sendMail(mailOptions);

    res.status(200).json({ message: " Support request sent successfully!" });
  } catch (error) {
    console.error("Error sending email:", error);
    res.status(500).json({ error: "Failed to send support request" });
  }
});


const db = require("./db");

//  ===================== save review in db ============================

app.post("/reviews/save", async (req, res) => {
  const { name, email, review, phone, rating, organization } = req.body;

  if (!name || !email || !review ||!rating,!phone,!organization) {
    return res.status(400).json({ error: "All fields are required!" });
  }

  try {
    // ---------- Save Review in DB ----------
    const sql = `
      INSERT INTO reviews ( name, email, review, phone, rating, organization,status )
      VALUES (?, ?, ?, ?, ?,?,'pending')
    `;  
    db.query(sql, [name, email, review, phone, rating, organization ], async (err, result) => {
      if (err) return res.status(500).json(err);

      // ---------- Send Email Notification ----------
      const transporter = nodemailer.createTransport({
        host: process.env.SUPPORT_EMAIL_HOST,
        port: parseInt(process.env.SUPPORT_EMAIL_PORT),
        secure: true,
        auth: {
          user: process.env.SUPPORT_EMAIL,
          pass: process.env.SUPPORT_PASS,
        },
      });

      const mjmlTemplate = `
        <mjml>
          <mj-body background-color="#f5f7fa">
            <mj-section>
              <mj-column background-color="#ffffff">
                <mj-text font-size="16px" color="#333333">
                  A new review has been submitted on your website. <br/><br/>
                </mj-text>
                <mj-text font-size="15px" color="#333333">
                  <strong>Name:</strong> ${name}<br/>
                  <strong>Email:</strong> ${email}<br/>
                  <strong>Organization:</strong> ${organization || "N/A"}<br/>
                  <strong>Phone:</strong> ${phone || "N/A"}<br/>
                  <strong>Review:</strong> ${review}<br/>
                </mj-text>
              </mj-column>
            </mj-section>
          </mj-body>
        </mjml>
      `;

      const { html } = mjml(mjmlTemplate);

      const mailOptions = {
        from: `"Review" <${process.env.SUPPORT_EMAIL}>`,
        replyTo: email,
        to: process.env.SUPPORT_RECEIVER,
        subject: "New Review Submitted",
        html: html,
      };

      await transporter.sendMail(mailOptions);

      return res.json({
        message: "Review saved successfully!",
        reviewId: result.insertId,
      });
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Server Error" });
  }
});


app.get("/reviews/list",(req,res) => {
  db.query(`SELECT * FROM reviews ORDER BY created_at DESC`,(err,result)=>{
    if(err) return res.status(500).json(err);
    return res.json(result);
  })
})

app.get("/reviews/pending",(req,res) => {
  db.query(`select * from reviews where status = 'pending'`,(err,result) => {
    if(err) return res.status(500).json(err);
    return res.json(result);
  })
})

  app.get("/reviews/public",(req,res) => {
    db.query(`select * from reviews where status = 'approved' order by id DESC`,(err,result)=>{
      if(err) return res.status(500).json(err);
      return res.json(result);
    })
  })

app.put("/reviews/update/status/:id/:status",(req,res) => {
  const {id,status} = req.params;
  db.query(`UPDATE reviews SET status = ? WHERE id = ?`,[status,id],(err,result) => {
    if(err) return res.status(500).json(err);
    return res.json(result);
  })

})

// ---------- Start Server ----------
const PORT = process.env.BACKEND_PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ Support API running on port ${PORT}`);
});
